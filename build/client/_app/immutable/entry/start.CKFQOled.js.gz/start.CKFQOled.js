import{l as o,a as r}from"../chunks/D4hUnIj_.js";export{o as load_css,r as start};
